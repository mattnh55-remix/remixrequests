import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { hashEmail } from "@/lib/security";

// TODO: Implement Square signature verification + mapping using a sample payload.
// This placeholder returns 200 so you can deploy and then harden in Phase 2.
export async function POST(req: Request) {
  const raw = await req.text();
  let event: any = null;
  try { event = JSON.parse(raw); } catch { /* ignore */ }

  // Placeholder: no-op
  // Once you provide a sample Square webhook payload, we’ll:
  // 1) verify signature using SQUARE_WEBHOOK_SIGNATURE_KEY
  // 2) extract buyer email
  // 3) map checkout link/item to credits and write to CreditLedger

  return NextResponse.json({ ok: true, received: !!event });
}
