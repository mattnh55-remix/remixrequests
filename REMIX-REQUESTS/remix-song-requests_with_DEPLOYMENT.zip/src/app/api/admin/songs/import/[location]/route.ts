import { NextResponse } from "next/server";
import { isAdminFromCookie } from "@/lib/adminAuth";
import { getRulesForLocation } from "@/lib/rules";
import { prisma } from "@/lib/db";
import { artistKeyFor, parseCsvSongs } from "@/lib/csv";

export async function POST(req: Request, { params }: { params: { location: string } }) {
  if (!isAdminFromCookie(req.headers.get("cookie"))) {
    return NextResponse.json({ ok: false }, { status: 401 });
  }

  const { loc } = await getRulesForLocation(params.location);
  const text = await req.text();

  let rows;
  try {
    rows = parseCsvSongs(text);
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || "Bad CSV" }, { status: 400 });
  }

  if (!rows.length) return NextResponse.json({ ok: false, error: "No valid rows found." }, { status: 400 });

  const batchSize = 250;
  let created = 0;

  for (let i = 0; i < rows.length; i += batchSize) {
    const batch = rows.slice(i, i + batchSize);
    await prisma.song.createMany({
      data: batch.map(r => ({
        locationId: loc.id,
        title: r.title,
        artist: r.artist,
        artistKey: artistKeyFor(r.artist),
        explicit: r.explicit,
        tags: r.tags,
        artworkUrl: r.artworkUrl
      }))
    });
    created += batch.length;
  }

  return NextResponse.json({ ok: true, created });
}
