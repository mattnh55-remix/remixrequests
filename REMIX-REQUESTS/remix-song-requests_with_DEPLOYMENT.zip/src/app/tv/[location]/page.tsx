"use client";

import { useEffect, useState } from "react";

type QItem = { id: string; title: string; artist: string; artworkUrl?: string; score: number };

export default function TvPage({ params }: { params: { location: string } }) {
  const location = params.location;
  const [playNow, setPlayNow] = useState<QItem[]>([]);
  const [upNext, setUpNext] = useState<QItem[]>([]);

  async function tick() {
    const res = await fetch(`/api/public/queue/${location}`, { cache: "no-store" });
    const data = await res.json();
    setPlayNow(data.playNow || []);
    setUpNext(data.upNext || []);
  }

  useEffect(() => {
    tick();
    const id = setInterval(tick, 3000);
    return () => clearInterval(id);
  }, []);

  return (
    <div style={{ height: "100vh", padding: 22, color: "white", background: "radial-gradient(1200px 700px at 20% 20%, #1b1b55 0%, #07070c 55%, #040406 100%)" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
        <div>
          <div style={{ fontSize: 44, fontWeight: 900, letterSpacing: -1 }}>REMIX • SONG REQUESTS</div>
          <div style={{ opacity: 0.75, fontSize: 18 }}>Scan the QR to request • Vote • Play Now</div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontSize: 22, fontWeight: 800 }}>skateremix.com/request/{location}</div>
          <div style={{ opacity: 0.8 }}>Starting at $5</div>
          <div style={{ marginTop: 10, width: 160, height: 160, borderRadius: 18, border: "1px solid #333", background: "#0b0b10", display: "grid", placeItems: "center" }}>
            <div style={{ opacity: 0.7 }}>[QR]</div>
          </div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.1fr 0.9fr", gap: 18, marginTop: 18, height: "calc(100vh - 140px)" }}>
        <div style={card}>
          <div style={h2}>UP NEXT</div>
          <div style={{ display: "grid", gap: 10 }}>
            {upNext.slice(0, 10).map((q, i) => (
              <Row key={q.id} idx={i + 1} item={q} />
            ))}
            {upNext.length === 0 ? <div style={{ opacity: 0.7 }}>No requests yet — be the first!</div> : null}
          </div>
        </div>

        <div style={{ display: "grid", gap: 18 }}>
          <div style={card}>
            <div style={h2}>PLAY NOW LANE</div>
            <div style={{ display: "grid", gap: 10 }}>
              {playNow.slice(0, 5).map((q, i) => (
                <Row key={q.id} idx={i + 1} item={q} />
              ))}
              {playNow.length === 0 ? <div style={{ opacity: 0.7 }}>No Play Now requests</div> : null}
            </div>
          </div>

          <div style={card}>
            <div style={h2}>TRENDING TONIGHT</div>
            <div style={{ opacity: 0.7 }}>(Phase 2: top requested songs)</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Row({ idx, item }: { idx: number; item: any }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "52px 1fr 60px", alignItems: "center", gap: 10, padding: 10, borderRadius: 16, border: "1px solid #1c1c2f", background: "rgba(10,10,20,0.75)" }}>
      <div style={{ fontSize: 18, fontWeight: 900, opacity: 0.85 }}>{idx}</div>
      <div>
        <div style={{ fontWeight: 900 }}>{item.title}</div>
        <div style={{ opacity: 0.75 }}>{item.artist}</div>
      </div>
      <div style={{ textAlign: "right", fontWeight: 900, opacity: 0.85 }}>{item.score}</div>
    </div>
  );
}

const card: any = { borderRadius: 22, border: "1px solid #222", background: "rgba(0,0,0,0.35)", padding: 16, overflow: "hidden" };
const h2: any = { fontSize: 18, fontWeight: 900, letterSpacing: 1, opacity: 0.9, marginBottom: 10 };
