"use client";

import { useEffect, useState } from "react";

const RAILS = ["All Ages","Adult Night","TikTok","DISCO","80s","90s","2000s","Boy Bands","Pop Hits","Mom’s Hits","Dad Rock"];

type Song = { id: string; title: string; artist: string; artworkUrl?: string; explicit: boolean; tags: string[] };

export default function RequestPage({ params }: { params: { location: string } }) {
  const location = params.location;
  const [email, setEmail] = useState("");
  const [search, setSearch] = useState("");
  const [tag, setTag] = useState<string>("");
  const [songs, setSongs] = useState<Song[]>([]);
  const [rules, setRules] = useState<any>(null);
  const [msg, setMsg] = useState<string>("");

  async function loadSession() {
    const res = await fetch(`/api/public/session/${location}`);
    setRules(await res.json());
  }

  async function loadSongs() {
    const qs = new URLSearchParams();
    if (search) qs.set("search", search);
    if (tag) qs.set("tag", tag);
    const res = await fetch(`/api/public/songs/${location}?${qs.toString()}`);
    const data = await res.json();
    setSongs(data.items || []);
  }

  useEffect(() => { loadSession(); }, []);
  useEffect(() => { loadSongs(); }, [search, tag]);

  async function submit(songId: string, action: "play_next" | "play_now") {
    setMsg("");
    const res = await fetch(`/api/public/request`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ location, email, songId, action })
    });
    const data = await res.json();
    if (!data.ok) setMsg(data.error || "Something went wrong.");
    else setMsg(action === "play_now" ? "✅ Play Now request added!" : "✅ Request added!");
  }

  return (
    <div style={{ padding: 18, maxWidth: 980, margin: "0 auto", color: "white" }}>
      <h1 style={{ fontSize: 28, marginBottom: 8 }}>Request a Song</h1>
      <div style={{ opacity: 0.8, marginBottom: 14 }}>{rules?.location?.name || location}</div>

      <div style={{ display: "grid", gap: 10, marginBottom: 12 }}>
        <input
          value={email}
          onChange={e => setEmail(e.target.value)}
          placeholder="Your email (for credits & rules)"
          style={{ padding: 12, borderRadius: 12, border: "1px solid #333", background: "#0b0b10", color: "white" }}
        />
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search title or artist…"
          style={{ padding: 12, borderRadius: 12, border: "1px solid #333", background: "#0b0b10", color: "white" }}
        />
        <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 6 }}>
          <button onClick={() => setTag("")} style={chip(tag === "")}>All</button>
          {RAILS.map(r => (
            <button key={r} onClick={() => setTag(r)} style={chip(tag === r)}>{r}</button>
          ))}
        </div>
      </div>

      {msg && <div style={{ marginBottom: 12, padding: 12, borderRadius: 12, background: "#121228" }}>{msg}</div>}

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: 12 }}>
        {songs.map(s => (
          <div key={s.id} style={{ borderRadius: 16, border: "1px solid #222", background: "#07070c", padding: 12 }}>
            <div style={{ display: "flex", gap: 10 }}>
              <div style={{ width: 56, height: 56, borderRadius: 12, background: "#111", flexShrink: 0, overflow: "hidden" }}>
                {s.artworkUrl ? <img src={s.artworkUrl} style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : null}
              </div>
              <div>
                <div style={{ fontWeight: 700 }}>{s.title}</div>
                <div style={{ opacity: 0.8 }}>{s.artist}</div>
                <div style={{ opacity: 0.6, fontSize: 12 }}>{s.tags?.slice(0,3).join(" • ")}</div>
              </div>
            </div>

            <div style={{ display: "grid", gap: 8, marginTop: 12 }}>
              <button disabled={!email} onClick={() => submit(s.id, "play_next")} style={btnPrimary}>
                Play Next • {rules?.rules?.costRequest ?? 1} credit
              </button>
              <button disabled={!email} onClick={() => submit(s.id, "play_now")} style={btnAlt}>
                Play Now • {rules?.rules?.costPlayNow ?? 5} credits
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

const btnPrimary: any = { padding: 12, borderRadius: 14, border: "1px solid #2b2b55", background: "#15153a", color: "white", fontWeight: 800 };
const btnAlt: any = { padding: 12, borderRadius: 14, border: "1px solid #333", background: "#0c0c16", color: "white", fontWeight: 800, opacity: 0.95 };
const chip = (active: boolean) => ({ padding: "10px 12px", borderRadius: 999, border: "1px solid #222", background: active ? "#1a1a44" : "#0b0b10", color: "white", whiteSpace: "nowrap" });
